#pragma once
#include <string>
int command(const std::string& komut);
