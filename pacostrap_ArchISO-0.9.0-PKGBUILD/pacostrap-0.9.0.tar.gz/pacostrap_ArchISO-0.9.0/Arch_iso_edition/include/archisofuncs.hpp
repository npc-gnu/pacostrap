#ifndef ARCHISOFUNCS_HPP
#define ARCHISOFUNCS_HPP
void a_usbmount();
void a_diskmount();
void a_diskpackage();
#endif
